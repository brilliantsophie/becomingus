package com.becomingus.controller.dto;

public record LoginResponseDto(String token) {}
