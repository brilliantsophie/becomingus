package com.becomingus.domain.user;

public enum Role {
    USER,   // 일반 사용자
    ADMIN   // 관리자
}
