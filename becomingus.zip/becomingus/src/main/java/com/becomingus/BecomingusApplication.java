package com.becomingus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BecomingusApplication {

	public static void main(String[] args) {
		SpringApplication.run(BecomingusApplication.class, args);
	}

}
